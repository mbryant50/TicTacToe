"""
Assignment 6

Please Note: Assignments are not meant to be group projects.
You must write your own code. Turning in code written by another student will result in you being reported to your
Provost for academic dishonesty. Learning and studying with others is fine, just do your own work. If you need help,
ask questions in class, come to office hours, or email us.

Warning: We know some of you may already know some python, or could find additional techniques by reading ahead in the
book or looking around online. That's fine, HOWEVER, you are to only use techniques we've covered in lecture or in the
book up to the week the assignment is given (includes the Thursday lecture the day after the assignment comes out).
We will be strict about this!

HOW TO TURN IN: You are to create the code files below, with the exact names specified below.
When finished, turn in all of your files on Canvas where you got the assignment prompt.
Do not email code to your instructor or TA! Code must be turned in via Canvas.
If you are turning in your code late, do it via Canvas (and incur the penalty – see the Syllabus).
If you can’t, then it’s too late even for late submission…there’s no benefit for your grade to emailing
us your code after this point.

"""

from zipfile import ZipFile
import shutil
from appJar import gui


def dash(d: int):
    dashes = "-" * 20
    print(f"\n{dashes}({d}){dashes}\n")


def reset_files(zip_filename: str):
    files_zip = ZipFile(zip_filename)
    if files_zip.testzip():
        print(f'Unable to find or unzip "{zip_filename}"')
    else:
        files_zip.extractall()


def set_font(window: gui, font_size: int):
    window.buttonFont = font_size
    window.labelFont = font_size
    window.entryFont = font_size
    window.optionFont = font_size
    window.webFont = font_size
    window.messageFont = font_size


"""
Instructions: See comments below, place you code beneath each one:

**************************************************************************************
NOTES: 1. All functions require Type Hints!!
       2. You need to import your own modules!!
       6. You can change the tests we write below each prompt if you'd like,
       4. You must use os-independent file paths (just let the Path module handle it!)
       5. None of the current assignment requires you to write a general file parser
          as we are currently working on in class. If you are asked to write a function
          that alters files, just use .glob to get the list of file paths, loop over it
          and apply your change to that file.
       6. For writing regular expression patterns, consider using regex101.com or regexr.com
**************************************************************************************
"""

"""
1. **Medium Rose Words**

Write a function called rose_family that has no parameters
Load in the text from rose_family.txt.
Replace any newline character with a space.
Use regular expressions to return a list of all of the 4, 5 or 6 letter words that *follows* each 4 letter word.
So search for 4-letter words that are followed by a 4-6 letter word.
Return the result as a list of strings.
Hint: You'll want to create sub-groups within your regular expression pattern.
Hint: Take it one step at a time: a) get the pattern to work on regex101.com, b) find all matches in the poem, 
      c) print out the matches, d) figure out how to create a list of just the words you want, e) return the list
"""
dash(1)
from pathlib import Path
import re
def rose_family():
    input_file=Path('files','textfiles','rose_family.txt')
    text=re.sub('\n', ' ', input_file.read_text())
    found_list = re.findall(r' [a-zA-Z]{4} ([a-zA-Z]{4,6})', text)
    ret_list=[]
    for entry in found_list:
        ret_list.append(entry)
    return ret_list
    
    
print(rose_family())
print(rose_family() == ['That', 'only', 'will', 'prove', 'always'])



"""
2. **Format Years**

write a function called format_years with no parameters.

Load in the text from the file movie_list_2018.txt
It has many lines formatted like this:

The Terminator = 1984
Mad Max 2: The Road Warrior = 1981
The Invisible Man = 1933
E.T. The Extra-Terrestrial = 1982

Use re.sub and regular expressions to change that format to this one:

The Terminator (1984)
Mad Max 2: The Road Warrior (1981)
The Invisible Man (1933)
E.T. The Extra-Terrestrial (1982)

return a single string with the altered result.

Hints: 
- Because left and right parentheses are used in RegEx patterns to denote groups, 
if you want to match an actual "(" or ")", then you need to escape them, e.g.: "\(" or "\)"
- You will need to use groups in your regular expression and refer to these groups in the replacement string.
- Unlike the search pattern, the replacement pattern can use parentheses without escaping them
"""
dash(2)
from pprint import pprint
def format_years():
    input_path=Path('files', 'textfiles', 'movie_list_2018.txt')
    text=input_path.read_text()
    updated=re.sub(r'= (\d{4})', r'(\1)', text)
    return updated

first_ten = \
    ['The Terminator (1984)',
     'Mad Max 2: The Road Warrior (1981)',
     'The Invisible Man (1933)',
     'E.T. The Extra-Terrestrial (1982)',
     'Aliens (1986)',
     'The Evil Dead (1981)',
     'Wings of Desire (1987)',
     'Brazil (1985)',
     'Forbidden Planet (1956)',
     'Alien (1979)']
pprint(format_years().splitlines()[:10])  # just first 10 lines
print(format_years().splitlines()[:10] == first_ten)  # just first 10 lines


"""
3. Increase Response Times
write a function called increase_rts with a parameter called folder that is 
expected to be a Path type object, and is assumed to represent a folder. 
Use Path.glob to get a list of path objects for each .csv file in the specified folder.
Loop over that list and for each one, load in the text, use re.sub to 
add 1000 to every 3 digit number, and write the text back to the same path object.
For example, this text:
Cond2,choicetask,Easy,1,720,Yellow,CORRECT
would become
Cond2,choicetask,Easy,1,1720,Yellow,CORRECT
You must use regular expressions to achieve this (re.sub to be exact) which means that 
you don't actually need to do a mathematical add, just find the 3-digit number and replace 
it with "1" followed by the original 3-digit number.
This function doesn't return anything, it just updates each of the files in the datafiles folder.
No error handling is required.
"""
dash(3)

def increase_rts(folder: Path):
    all_files= folder.glob('*.csv')
    for entry in all_files:
        text=entry.read_text()
        updated=re.sub(r'(\d{3})', r'1\1', text)
        entry.write_text(updated)

shutil.rmtree('files')
reset_files('files.zip')

end_bit = """\
Cond2,choicetask,Easy,26,1650,Green,CORRECT
Cond2,choicetask,Easy,27,1566,Red,CORRECT
Cond2,choicetask,Easy,28,1616,Green,CORRECT
Cond2,choicetask,Easy,29,1466,Blue,CORRECT"""

increase_rts(Path('files', 'datafiles'))
print(Path('files', 'datafiles', 'data_file_3.csv').read_text()[-173:-1])
print(Path('files', 'datafiles', 'data_file_3.csv').read_text()[-173:-1] == end_bit)


"""
4. Simple Window
create a function called simple_window that takes no parameters.
Create a gui that looks like this (the window size is 400 x 200 pixels):
https://goo.gl/Zb3yA8
When the OK button is pressed, the window should close.

---
 
WARNING app.setFont() doesn't work properly on macs. 
So use the set_font() function I've created above 
(The window parameter is your gui object).
So use it like this:

app = gui()
set_font(window=app, font_size=18)

then go on to build the elements of your gui.
Note: You must put your button handler function INSIDE this function.
      Yes, you can have a function within a function! 
      Just make sure you define the button handler BEFORE you add
      the button.
"""
dash(4)
from appJar import gui

def simple_window():
    app=gui("simple window")
    app.setFont(18)
    app.setGeometry(400,200)
    app.addLabel("lb1", "This is an appJar window!")
    app.addLabel("lb2", "This label has a red background")
    app.addLabel('lb3', "This label has a brown foreground")
    app.addButton('OK', app.stop)
    app.setLabelBg('lb2', 'red')
    app.setLabelFg('lb3', 'brown')
    app.go()
    
simple_window()


"""
5. Experiment Parameter Window
Outside your function:
    - Create a namedtuple called ParameterInfo with these fields: userid, session, condition
    - Create a global variable called parameters and set it to None
Then:
    create a function called get_parameters that takes no parameters.
    Create a gui that looks like this (the window size is 400 x 200 pixels):
    https://goo.gl/G89zVm
    within you button handler function (itself inside your get_parameters function) issue this command:
        global parameters
    so that you can update the global parameters value as follows:
    When the OK button is pressed, set parameters to a ParameterInfo namedtuple containing
    all the user's parameters, and then close the window.
    When the CANCEL button is pressed, set parameters to None, and then close the window.
    When the RESET button is pressed, each of the fields should be cleared.
    When you function ends, you don't have to return anything.
    You also don't have to handle any errors.
Note: the window background is "orange"
---

WARNING app.setFont() doesn't work properly on macs. 
So use the set_font() function I've created above 
(The window parameter is your gui object).
So use it like this:

app = gui()
set_font(window=app, font_size=18)

then go on to build the elements of your gui.
Note: You must put your button handler function INSIDE this function.
      Yes, you can have a function within a function! 
      Just make sure you define the button handler BEFORE you add
      the button.
"""
dash(5)
import collections
ParameterInfo=collections.namedtuple('ParameterInfo','userid session condition')
parameters=None
def get_parameters():
    
    def press(btn: str):
        global parameters
        if btn=='Cancel':
            parameters=None
            app.stop()
        if btn=='Reset':
            app.setEntry(["User I.D.:","Session Number:","Condition:"], '')
        if btn=='OK':
            parameters=ParameterInfo(app.getEntry('User I.D.:'), app.getEntry('Session Number:'), app.getEntry('Condition:'))
            app.stop()
    
    app=gui('Experiment Parameters')
    app.setFont(18)
    app.setGeometry(400,200)
    app.setBg('orange')
    app.addLabel('lb1', 'Enter Experiment Parameters')
    app.addLabelEntry("User I.D.:")
    app.addLabelEntry("Session Number:")
    app.addLabelEntry("Condition:")
    app.addButtons(["OK", "Reset", 'Cancel'], press, colspan=3)
    app.go()


get_parameters()  # Enter 101, 2, and A2 as the 3 values and press OK to get True below
print(parameters)
print(parameters == ParameterInfo(userid='101', session='2', condition='A2'))

