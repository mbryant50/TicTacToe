# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

"""

MIDTERM 2

1. You are not allowed to use NOTES, BOOKS, or ANY INTERNET SITE during the midterm.
   If we see any site open other than Canvas, you will receive a 0 on your exam.
   Even though lecture notes and other reference material are stored on our Canvas
   site, you are not allowed to use them during the exam.

2. ALL of your functions are required to feature type hints that mark the type expected for each parameter.

3. None of the functions you write should update/alter the input parameters. E.g., if a
   list is passed to your function as a parameter argument, that list should not be updated directly.

4. If you find yourself spending too much time on a question, seriously consider moving on to
   the next one, or at least checking to see if there are questions further down that you feel
   you could answers more quickly. The goal is to answer as many as you can, it's no use
   spending the entire time stuck on one answer.

"""

from pprint import pprint


def dash(d: int):
    dashes = "-" * 20
    print(f"\n{dashes}({d}){dashes}\n")


"""
Instructions: See comments below, place you code beneath each one:

NOTES: 1. You shouldn't use regular expressions on this exam.
       2. Some problems require you to import modules.
       3. You are not allowed to use any modules that we have yet to cover
       4. If you are already adept at using list comprehensions, you are welcome to do so.
       5. Your file reads must be operating system independent
       6. Use of "for VAR in range(len(SEQUENCE))" for the purposes of iterating over a sequence is not allowed.
          HOWEVER, you may use this pattern if your goal is to just iterate the number of times
          specified by a sequence's length. Thus, you're allowed to use this pattern as long as it is not
          a substitute for "for VAR in SEQUENCE". A good rule of thumb for when you use of ok: Are you actually
          using the value inside of VAR? If so, you don't need range(len()). If you are not using VAR,
          then you're probably in the clear.
       7. Understanding the questions isn't supposed to be hard! If you have a question, or many, please ask!!
          Let us decide what we can and cannot tell you...if you have a question, just raise your hand.
"""

"""
1. Numerical Obfuscation
The ord() function returns an integer representation of alphabetic characters. 
For example, ord('a') == 97, and ord('r') == 114.
Write a function called name_value() that takes a single list parameter called names. 
The function should return a list of the names' summed values as integers. 
Example: name_value(names=["Travis", "Mal", "Trevor", "Jayne"]) == [633, 282, 642, 503]
"""
dash(1)
def name_value(names: list):
    num_list=[]
    for name in names:
        val=0
        for char in name:
            val+=ord(char)
        num_list.append(val)
    return num_list
print(name_value(names=["Travis", "Mal", "Trevor", "Jayne"]) == [633, 282, 642, 503])

"""
2. Secret Message
Write a function called secret_message() that takes a string parameter called text and a tuple parameter called 
positions, which will be full of integers. The function should use the integers as indices into the string and 
return a string of those indices' values, in order.
Example: secret_message(text = "abcdefghijklmnopqrstuvwxyz", positions=(2, 0, 20)) == "cat"
Using try/except to:
a) If text is not a string, return the string "Error: text must be a string"
b) If positions is not an tuple, return the string "Error: positions must be a tuple"
"""
dash(2)
def secret_message(text: str, positions:tuple):
    fin_string=''
    i=0
    try:
        while i<len(positions):
            fin_string+=text[positions[i]]
            i+=1
    except IndexError:
        return('Error: text must be a string')
    except TypeError:
        return('Error: positions must be a tuple')
    return fin_string

         
print(secret_message(text="abcdefghijklmnopqrstuvwxyz", positions=(2, 0, 20)) == "cau")
print(secret_message(text=('a', 'b', 'c', 'd'), positions=(2, 0, 20)) == "Error: text must be a string")
print(secret_message(text="abcdefghijklmnopqrstuvwxyz", positions=2020) == "Error: positions must be a tuple")

"""
3. Shout
Write a function called shout with a string parameter called message and an integer parameter called repetitions.
Return a string that contains a number of copies of message, separated by newline characters. The number is
dictated by repetitions. So if message is "Hello" and repetitions is 3, your function should return

Hello
Hello
Hello

Using try/except to:
a) If message is not a string, return the string "Error: message must be a string"
b) If repetitions is not an integer, return the string "Error: repetitions must be an integer"
"""
dash(3)
def shout(message: str, repetitions: int):
    i=0
    new_str=''
    try:
        while i<repetitions:
            try:
                new_str+=message.title()+'\n'
                i+=1
            except (TypeError, AttributeError):
                return('Error: message must be a string')
        return new_str
    except TypeError:
        return('Error: repetitions must be an integer')
        

shouted = """Live Long And Prosper
Live Long And Prosper
Live Long And Prosper
Live Long And Prosper
"""
print(shout(message="live long And prosper", repetitions=4))
print(shout(message="live long And prosper", repetitions=4) == shouted)
print(shout(message=4, repetitions=4) == "Error: message must be a string")
print(shout(message="live long And prosper", repetitions="4") == "Error: repetitions must be an integer")

"""
4. Sorting and Randomizing Lists.
Create a namedtuple with these fields: sorted and shuffled
write a function call list_modes that accepts 1 list parameter called a_list.
Return an instance of your named tuple where sorted is assigned to a sorted copy of a_list,
and shuffled is assigned to a randomized copy of the input list.
Do not alter the input list directly, make copies!
Note: You can shuffle a list using the random.shuffle method. It shuffles in place...it does not return a new list!
"""
dash(4)

import collections
import random
SortList=collections.namedtuple('SortList', 'sorted shuffled')
def list_modes(a_list:list):
    copy_list_a=[]
    x=len(a_list)
    j=0
    while j<x:
        copy_list_a.append(a_list[j])
        j+=1
    sort_list=[]
    i=0
    while i<x:
        sort_list.append(min(copy_list_a))
        copy_list_a.remove(min(copy_list_a))
        i+=1
    copy_list_b=[]
    k=0
    while k<x:
        copy_list_b.append(a_list[k])
        k+=1
    shuff_list=random.shuffle(copy_list_b)
    ret_val=SortList(sort_list, shuff_list)
    return ret_val
        

my_list = [8, 6, 7, 5, 3, 0, 9]
result = list_modes(a_list=my_list)
pprint(result)
print(result.shuffled != my_list and result.sorted != my_list)
print(my_list == [8, 6, 7, 5, 3, 0, 9])  # see if input list was altered
my_number = [1, 2, 3, 4, 5, 6, 7, 8, 9]
result = list_modes(a_list=my_number)
pprint(result)
print(result.shuffled != my_number and result.sorted == my_number)
print(my_number == [1, 2, 3, 4, 5, 6, 7, 8, 9])  # see if input list was altered

"""
5. Opening Files The New Way
Write a function called newopen with 2 string parameters: pathname and filename
Using ONLY the pathlib module, open the specified file and return the 1st line of text (without the newline character). 
You do not need the os module for this problem. You are not to use the open() function at all.
If the file specified does not exist, return None.
"""
dash(5)
from pathlib import Path
def newopen(pathname:str, filename:str):
    try:
        file_path=Path(pathname.join(filename))
        input_file=file_path.read_text()
        output_file= ''
        for char in input_file:
            if char=='\n':
                break
            else:
                output_file+=char
    except FileNotFoundError:
        return None
print(newopen(pathname="files", filename="movie_list_2018.txt"))
print(newopen(pathname="files", filename="movie_list_2018.txt") == "The Terminator = 1984")
print(newopen(pathname="files", filename="love_train.txt") == "People all over the world (everybody)")
print(newopen(pathname="files", filename="captains.txt") is None)

"""
6. Framed Text
Write a function called framed_text with 1 string parameters call text
create a version of the poem that is framed and title cased like this:
IF THIS IS THE ORIGINAL:

roses are red
violets are blue
I program Python
and so do you

THEN YOUR FRAMED VERSION SHOULD LOOK LIKE THIS:

==================
==Roses Are Red===
=Violets Are Blue=
=I Program Python=
==And So Do You===
==================

To achieve this, you will need to figure out which line of the text is the longest
and then you can center each line around this length. Make sure to consider the space
taken up by the frame. 
Please note, solving this one requires 2 stages: 
1) figure out the max line length, 2) center the poem within a frame.
To get the max line length, you can use Python's max(SEQUENCE) function on a list of the line lengths.
Of course, you'd first have to create such a list. 
When you're done, return the framed version of the text
"""
import re
dash(6)
def framed_text(text:str):
    x=text.split('\n')
    retval=''
    i=0
    while i<len(x)-1:
        if len(x[i])>len(x[i+1]):
            longest=len(x[i])
        else:
            longest=len(x[i+1])
        i+=1
    width=longest+2
    height= len(x)+2
    h=0
    while h<=height:
        if (h==0 or h==height):
            retval+=('='*width)+'\n'
        else:
            line=(x[h])
            line.center(width,'=')
        h+=1
        
        


unframed_bad_poem = """\
roses are red
violets are blue
I program Python
and so do you
"""
framed_bad_poem = """\
==================
==Roses Are Red===
=Violets Are Blue=
=I Program Python=
==And So Do You===
=================="""
print(framed_text(text=unframed_bad_poem))
print(framed_text(text=unframed_bad_poem).strip() == framed_bad_poem)

"""
7. Filtered Counts
Write a function called counts_n_graph with 2 string parameters: pathname and filename,
and 1 integer parameter called minimum
Open the file using pathlib and read in its text.
Turn any double spaces or newlines into single spaces
use string.punctuation to remove all punctuation from the text. 
make the entire text lowercase. 
split the text into a list of words. 
Create a dictionary to count the occurrences of each word in the word list.
Remove all dictionary keys with a value of less than the minimum.
Note, you can either go through the dictionary and delete the keys with insufficient values,
or you can loop through the items and create a new dictionary with only the acceptable items.
Either way, return a dictionary with any values lower than the minimum removed.
Return the the dictionary.

"""
dash(7)



# pprint(filtered_counts(pathname='files', filename='love_train.txt', minimum=4))
# pprint(filtered_counts(pathname='files', filename='love_train.txt', minimum=4) ==
#        {'Join': 12, 'People': 9, 'Start': 10, 'a': 10,
#         'all': 14, 'come': 7, 'hands': 8, 'in': 7,
#         'it': 4, 'love': 23, 'no': 4, 'on': 14, 'over': 12,
#         'ride': 12, 'the': 19, 'this': 7, 'train': 28,
#         'world': 13, 'yall': 4, 'you': 6})

"""
8. Selecting Records
Write a function called record_select with 3 string parameters: pathname, filename, and search.
First create a namedtuple with these fields: first, last, phone, and sport.
Read in the lines from the supplied text file. Each line will contain a comma separated list of the
first name, last name, phone number, and fav sport of one person.
Create a list of namedtuples from each of the lines in the file.
You are to return this list of namedtuples, however, you are only to return a list of namedtuples
containing people whose LAST NAME starts with whatever text is given by the search parameter.
If the specified file does not exist, return None.
"""
dash(8)


# pprint(record_select(pathname='files', filename='faculty_records.txt', search="T") ==
#        [FacultyRecord(first='Molly', last='Telles', phone='555-9375', sport='Dancesport'),
#         FacultyRecord(first='Robyn', last='Tes', phone='555-6886', sport='Rounders'),
#         FacultyRecord(first='Jolinda', last='Terschluse', phone='555-6783', sport='Bridge'),
#         FacultyRecord(first='Stacy', last='Truong', phone='555-7101', sport='Greyhound Racing'),
#         FacultyRecord(first='Kelly', last='Takano', phone='555-1571', sport='Boule Lyonnaise'),
#         FacultyRecord(first='Melissa', last='Turpin', phone='555-8190', sport='Taekwondo'),
#         FacultyRecord(first='Samantha', last='Tan', phone='555-4231', sport='Sports Fishing'),
#         FacultyRecord(first='Elizabeth', last='Tsujimoto', phone='555-9029', sport='Shinty'),
#         FacultyRecord(first='Ashley', last='Tower', phone='555-9838', sport='Parkour'),
#         FacultyRecord(first='Melissa', last='Tuazon', phone='555-5165', sport='Soft Tennis'),
#         FacultyRecord(first='Anne', last='Thaler', phone='555-9083', sport='Football 7-A-Side')])
#
# pprint(record_select(pathname='files', filename='faculty_records.txt', search="G") ==
#        [FacultyRecord(first='Aj', last='Gomez', phone='555-1742', sport='Hapkido Boxing'),
#         FacultyRecord(first='Jeremy', last='Gillan', phone='555-9021', sport='Wheelchair Fencing')])
#
# pprint(record_select(pathname='files', filename='FacultyRecords.txt', search="X") is None)

"""
9. Rock Paper Scissors
Code a rock paper scissors function called rps(). Use one list parameter called player_moves.
create a dictionary with these keys: "wins", "losses", "draws".
the user input strings can only be the characters r, p, or s. 
On each attempt, the computer's guess should be a random choice of r, p or s and then decide if the user won lost or
tied (a draw). Eventually, you end up with a dictionary describing the results, 
e.g.: {'wins': 4, 'losses': 2, 'draws': 3}
In addition to returning the dictionary describing the number of wins, losses, and draws, return a list
of the movies, each game should be stored in a tuple, 
e.g.: [('r', 'p'), ('s', 's')]
Return a tuple with the first item being the moves and the second being the results.
In case you aren't familiar with RPS, R=Rock, P=Paper, and S=Scissors. Rock beats Paper, Paper beats Rock, and 
Scissors beats Paper. Any duplicates (e.g, Rock, Rock) are considered draws/ties and any other combination is a
loss. So r->p is a win (for the person on the left), s->s is a draw, and s->r is a loss (for the person on the left).
"""
dash(9)


# history, results = rps(player_moves=list('rpsrpsrps'))
# pprint(history)
# pprint(results)

# NOTE: We aren't offering a test here because the outcome is random. However, the prompt shows you what the
# history and result should generally look like.
