"""
Assignment 3

Please Note: Assignments are not meant to be group projects.
You must write your own code. Turning in code written by another student will result in you being reported to your
Provost for academic dishonesty. Learning and studying with others is fine, just do your own work. If you need help,
ask questions in class, come to office hours, or email us.

Warning: We know some of you may already know some python, or could find additional techniques by reading ahead in the
book or looking around online. That's fine, HOWEVER, you are to only use techniques we've covered in lecture or in the
book up to the week the assignment is given (includes the Thursday lecture the day after the assignment comes out).
We will be strict about this!

HOW TO TURN IN: You are to create the code files below, with the exact names specified below.
When finished, turn in all of your files on Canvas where you got the assignment prompt.
Do not email code to your instructor or TA! Code must be turned in via Canvas.
If you are turning in your code late, do it via Canvas (and incur the penalty – see the Syllabus).
If you can’t, then it’s too late even for late submission…there’s no benefit for your grade to emailing
us your code after this point.

"""
def dash(d: int):
    dashes = "-" * 20
    print(f"\n{dashes}({d}){dashes}\n")

"""
Instructions: See comments below, place you code beneath each one:
"""

"""
1. Create a function called combiner with 3 parameters, list1, list2, and list3.
Your function should return a list whose items are the combined values of the 3 input lists.
The length of the returned list should be the sum of the lengths of the 3 input lists.
If the parameters are [1, 2, 3], [4, 5, 6], and [7, 8, 0], 
the output should be [1, 2, 3, 4, 5, 6, 7, 8, 0]
"""
dash(1)

def combiner(list1, list2, list3):
    i=0; j=0; k=0
    combined=[]
    while i<len(list1):
        combined.append(list1[i])
        i+=1
    while j<len(list2):
        combined.append(list2[j])
        j+=1
    while k<len(list3):
        combined.append(list3[k])
        k+=1
    return combined

print(combiner(list1=[1, 2, 3], list2=[4, 5, 6], list3=[7, 8, 0]))

"""
2. Create a function called appender with 3 parameters, list1, list2, and list3.
Your function should return a list whose items are the 3 input lists.
The length of the returned list should be 3.
If the parameters are [1, 2, 3], [4, 5, 6], and [7, 8, 0], 
the output should be [[1, 2, 3], [4, 5, 6], [7, 8, 0]]
NOTE: Make sure you use list.append to solve this one.!
"""
dash(2)

def appender(list1, list2, list3):
    final=[]
    final.append(list1)
    final.append(list2)
    final.append(list3)
    return final

print(appender(list1=[1, 2, 3], list2=[4, 5, 6], list3=[7, 8, 0]))

"""
3. Create a function called appender2 with 4 parameters, list1, list2, list3, tupelify.
The parameter tupelify should default to False
Your function should return a list whose items are the 3 input lists.
The length of the returned list should be 3.
If tupelify is false, and the parameters are [1, 2, 3], [4, 5, 6], and [7, 8, 0], 
the output should be [[1, 2, 3], [4, 5, 6], [7, 8, 0]]
However, if tupelify is true, the output should be:
((1, 2, 3), (4, 5, 6), (7, 8, 0))
"""
dash(3)

def appender2(list1, list2, list3, tupelify=False):
    final=[]
    final.append(list1)
    final.append(list2)
    final.append(list3)
    if tupelify==True:
        final=(tuple(list1), tuple(list2), tuple(list3))
    return final
    

print(appender2(list1=[1, 2, 3], list2=[4 ,5, 6], list3=[7, 8, 0], tupelify=True))
print()
print(appender2(list1=[1, 2, 3], list2=[4, 5, 6], list3=[7, 8, 0], tupelify=False))

"""
4. Create a function called is_awesome that takes a single string parameter called text.
Your function should contain within it a list of 10 star wars character names.
your function should return True, if the string text has any of the star wars character names in it.
Otherwise, it should return False. Assume that your list of character names uses title case for each name,
and only return True if the string text refers to contains the same title case reference. Thus, if your
function contains "R2D2" in its awesome list, but the string contains "r2d2", then your function should
return False.
Hint, you will need to use the **in** keyword.
"""
dash(4)

def is_awesome(text):
    good_list=['Jango Fett', 'Jar Jar Binks', 'Chancellor Palpatine', 'Qui Gon Jinn', 'Ben Solo', 'Padme Amidala', 'Stormtrooper', 'Ewok', 'General Grievous', 'Dr. Spock']
    i=0
    while i<len(good_list):
        if (((good_list[i]) in text) !=True):
            i+=1
            if i == len(good_list):
                return False
        else:
            return True
       
        
        
    

print(is_awesome(text="Princess Leia, I'm Luke Skywalker..I'm here to save you"))
print(is_awesome(text="You prefer another target, perhaps a military target, then name the system!"))

"""
5. Create a function called i_hate_friends with a parameter called character_names. Use a type hint to
document that this parameter should be a list. Inside your function, you need a list of these names:
Rachel, Monica, Phoebe, Joey, Chandler, and Ross. Return a version of the input list where any of
these names has been removed. So if the input list is ["Travis", "Joey", "Magdelena", "Rachel"], the
output should be ["Travis", "Magdelena"].

WARNING: Do not alter/update character_names itself! 

You are to make a new list based on the values
in character_names. You may either copy character_names and then edit its contents, or you can
loop through character_names and add items to a new empty list you've created beforehand.
"""
dash(5)

def i_hate_friends(character_names: list):
    friends_list=['Rachel', 'Monica', 'Phoebe', 'Joey', 'Chandler', 'Ross']
    new_list=[]
    i=0
    while i<len(character_names):
        if (((character_names[i]) in friends_list)==False):
            new_list.append(character_names[i])
        i+=1
    return new_list
                
print(i_hate_friends(character_names=["Ross", "Monica"]))
original_list = ["Travis", "Joey", "Magdelena", "Rachel", "Gina", "Chandler"]
print(original_list)
print(i_hate_friends(character_names=["Travis", "Joey", "Magdelena", "Rachel", "Gina", "Chandler"]))
print(original_list)  # should be the same as before!!

"""
**** **** **** **** **** **** **** **** **** **** **** **** 
**** **** **** **** **** **** **** **** **** **** **** **** 
NOTE: Below, if I ask you to "mark" a parameter as an int or 
some other type, I'm referring to the concept of 
"type hinting" that we discussed on thursday.
**** **** **** **** **** **** **** **** **** **** **** **** 
**** **** **** **** **** **** **** **** **** **** **** **** 
"""


"""
6. Create a function called slice_text that requires a string input called text (mark it as a string).
There should be 2 other parameters start and stop (mark these as ints).
Use slicing to return the character indicated by the start parameter up to the character indicated by the stop parameter.
If the stop parameter is not greater than the start parameter, return None.
NOTE: the string you return should include the character indicated by the stop parameter.
So slice_text(text="California", start=3, stop=6) should return "ifor", not "ifo"
"""
dash(6)

def slice_text(text: str, start: int, stop: int):
    if stop<=start:
        return None
    text_list= list(text)
    final=''
    i=start
    while i<stop+1:
        final+=str(text_list[i])
        i+=1
    return str(final)

print(slice_text(text="California", start=3, stop=6))
print(slice_text(text="Michigan", start=6, stop=3))
print(slice_text(text="Illinois", start=3, stop=4))



"""
7. Create a function called slice_list with a parameter called items instead of text (mark items as a list).
Otherwise this is the same as #6. E.g.:
slice_list(items=['a', 'b', 'c', 'd', 'e', 'f'], start=1, stop=4) should return ['b', 'c', 'd', 'e']
"""
dash(7)

def slice_list(items: list, start: int, stop: int):
    if stop<=start:
        return None
    final=[]
    i=start
    while i<stop+1:
        final.append(items[i])
        i+=1
    return str(final)

print(slice_list(items=['a', 'b', 'c', 'd', 'e', 'f'], start=1, stop=4))
print(slice_list(items=['a', 'b', 'c', 'd', 'e', 'f'], start=4, stop=1))
print(slice_list(items=['a', 'b', 'c', 'd', 'e', 'f'], start=-4, stop=-1))

"""
8. Create a function called prettify that takes a list of strings (call the parameter items and mark it as a list).
Also accept a str parameter (mark it as such) called char and default it to "~".
Add a third parameter called rep and mark it as an integer. Default it to 1.
For each string item in the list, add 1 instance of char to the front and the back if rep is equal to 1.
Otherwise, add the number of chars specified by rep. 
Return a list of the altered strings. E.g.:

prettify(items=["Just", "Do", "It"], char="*", rep=2) should return ["**Just**", "**Do**", "**It**"]
prettify(items=["Just", "Do", "It"], rep=3) should return ["~~~Just~~~", "~~~Do~~~", "~~~It~~~"]

HINT: If I were writing this function, I'd make use of f-strings. 

Please avoid redundancy where possible.
"""
dash(8)

def prettify(items: list, char: str = '~', rep: int = 1):
    i=0
    new_list=items
    while i<len(items):
        new_list[i]=((char*rep)+str(items[i])+(char*rep))
        i+=1
    return new_list

print(prettify(items=["Just", "Do", "It"], char="*", rep=2))
print(prettify(items=["Just", "Do", "It"], rep=3))
print(prettify(items=["Just", "Do", "It"]))

"""
9. write a function called silly that accepts a string parameter called text (mark it as a string).
Return a new string where all of the "e"s have been changed to "0"s and all the "s"s have been changed to "5"s.
You cannot use str.replace for this function (I recommend iterating over the original string and building a new one).
"""
dash(9)

def silly(text: str):
    new_str=''
    i=0
    while i<len(text):
        if text[i]=='e':
            new_str+='0'
        elif text[i]=='s':
            new_str+='5'
        else:
            new_str+=text[i]
        i+=1
    return new_str

print(silly(text="I suggest a new strategy, Artoo: let the Wookie win."))

"""
10. Write a function called str_case that takes a parameter called text (marked as a string).
Your function should return one of the following strings: "lowercase", "uppercase", "titlecase"
depending on whether text is lower, upper or title case.
If text is an empty string, return the value None.
"""
dash(10)

def str_case(text: str):
    if text=='':
        return None
    elif (text[1].isupper())==True:
        return 'uppercase'
    elif (text[0].isupper())==True:
        return 'titlecase'
    else:
        return 'lowercase'
        

print(str_case('Margaret Hamilton'))
print(str_case('ADA LOVELACE'))
print(str_case("grace hopper"))
print(str_case(""))

"""
11. Create a program called int_lister that continually asks the user for integers. 
Append each number to a list called my_numbers. 
my_numbers must contain actual integer representations of the numbers entered, not strings!
If the user enters the string "show", then print the list of numbers. 
If the user enters an empty string, exit the loop.
If the user enters something that is not an empty string, is not the word "show" and is not an integer,
tell them that they can only enter integers, the word "show" or nothing if they want to quit.
Note: This is a void function, it doesn't return anything!
"""
dash(11)

def int_lister():
    integers=[]
    x=1
    while x==1:
        i = input('Gimme an integer (type "show" to show it off, hit "enter" to quit): ')
        if i== 'show':
            print(integers)
        elif i=='':
            x=0
        elif i.isdigit():
            integers.append(i)
        else:
            print('How many times i gotta tell ya B, integers, "show", or enter')
        
            
        
int_lister()