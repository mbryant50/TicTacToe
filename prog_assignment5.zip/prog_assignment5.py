# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 00:57:59 2018

@author: mibryant
"""

# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

"""
Assignment 4

Please Note: Assignments are not meant to be group projects.
You must write your own code. Turning in code written by another student will result in you being reported to your
Provost for academic dishonesty. Learning and studying with others is fine, just do your own work. If you need help,
ask questions in class, come to office hours, or email us.

Warning: We know some of you may already know some python, or could find additional techniques by reading ahead in the
book or looking around online. That's fine, HOWEVER, you are to only use techniques we've covered in lecture or in the
book up to the week the assignment is given (includes the Thursday lecture the day after the assignment comes out).
We will be strict about this!

HOW TO TURN IN: You are to create the code files below, with the exact names specified below.
When finished, turn in all of your files on Canvas where you got the assignment prompt.
Do not email code to your instructor or TA! Code must be turned in via Canvas.
If you are turning in your code late, do it via Canvas (and incur the penalty – see the Syllabus).
If you can’t, then it’s too late even for late submission…there’s no benefit for your grade to emailing
us your code after this point.

"""
import collections
from pprint import pprint


def dash(d: int):
    dashes = "-" * 20
    print(f"\n{dashes}({d}){dashes}\n")


"""
Instructions: See comments below, place you code beneath each one:

************************************************
****NOTE: All functions require Type Hints!!****
************************************************
"""

"""
1. Use try/accept to make sure the following function is passed a password argument that is a string.
Start by seeing what exception is raised if it is called with a non-string. Then handle that exception.
If an exception is raised, return the value None.
"""
dash(1)


def password_ok(password: str):
    
    bad_words = 'password 12345678 pass123 querty letmein 111111'.split(' ')
    try:
        req1 = password not in bad_words
        req2 = not password.isupper()
        req3 = len(password) > 6 and len(password) < 13
        if req1 and req2 and req3:
            return True
        else:
            return False
    except (TypeError, AttributeError):
        return None

print(password_ok(password='234234234'))
print(password_ok(password='234234234') is True)
print(password_ok(password='pass123') is False)
print(password_ok(password=38) is None)

"""
2. Write a function called e_count that has a parameter called text (a string), and a parameter called
target (an integer). Your function should return one of these strings: ">", "<", or "=" depending
on whether the number of e's (lowercase only) in the string are >, < or == the value 
represented by the target parameter. 
Use a try/except with two different except sections to handle 1) what happens if a non-string is 
passed as text (what kind of exception is raised here?) and 2) what happens if target is not a number.
If an exception is raised, return either "ERROR: text must be a string!" or "ERROR: target must be a number!".
Note, use the EXACT error messages specified above!
"""
dash(2)

def e_count(text: str, target: int):
    counter=0
    try:
        for i in text:
            if i=='e':
                counter+=1
    except TypeError:
        return("ERROR: text must be a string!")
    try:
        if counter<target:
            return("<")
        elif counter>target:
            return(">")
        else:
            return("=")
    except TypeError:
        return("ERROR: target must be a number!")
    

s = "Peter Piper picked a peck of pickled peppers. How many pickled peppers did Peter Piper pick?"  # there are 14 e's
print(e_count(text=s, target=13))
print(e_count(text=s, target=13) == ">")
print(e_count(text=s, target=15) == "<")
print(e_count(text=s, target=14) == "=")
print(e_count(text=100, target=150) == "ERROR: text must be a string!")
print(e_count(text=s, target="hello") == "ERROR: target must be a number!")

"""
3. Re-Write the above function (but call it e_count2) so that there is just ONE except clause 
that handles both exceptions. Print this exact message: 
"ERROR: text must be a string and target must be a number!".
Note: Do not use a general except block (that would handle ALL exceptions)!
      Just handle the same two you handled above.
"""
dash(3)

def e_count2(text: str, target: int):
    try:
        counter=0
        for i in text:
            if i=='e':
                counter+=1
        if counter<target:
            return("<")
        elif counter>target:
            return(">")
        else:
            return("=")
    except TypeError:
        return "ERROR: text must be a string and target must be a number!"

s = "Peter Piper picked a peck of pickled peppers. How many pickled peppers did Peter Piper pick?"  # there are 14 e's
print(e_count2(text=s, target=13))
print(e_count2(text=s, target=13) == ">")
print(e_count2(text=s, target=15) == "<")
print(e_count2(text=s, target=14) == "=")
print(e_count2(text=100, target=150) == "ERROR: text must be a string and target must be a number!")
print(e_count2(text=s, target="hello") == "ERROR: text must be a string and target must be a number!")

"""
4. 
a. Create a function called word_info that takes a string parameter called text
b. Split this into words using the str.split method (not the space counting approach)
c. FOR EACH WORD, 
    - Calculate the following:
    i. Number of characters in the word
    ii. Whether or not it is uppercase (True or False)
    iii. Whether or not it is lowercase (True or False)
    - Then store these values in namedtuple called "WordInfo" with these field names: 
       "word", "chars", "uppercase", and "lowercase"
    - Then add this namedtuple to a list.
d. return the list of namedtuples
Note: the collections module and the pprint function have already been imported for you
"""
dash(4)

# DEFINE YOUR NAMEDTUPLE HERE
WordInfo= collections.namedtuple('WordInfo', 'word chars uppercase lowercase')
# DEFINE YOUR FUNCTION HERE
def word_info(text: str):
    text_list= text.split(' ')
    new_list=[]
    for i in text_list:
        record= WordInfo(i, (len(i)), i.isupper(), i.islower())
        new_list.append(record)
    return new_list

s = "Peter Piper picked a peck of PICKLED peppers."
pprint(word_info(s))
print(word_info(s) == [WordInfo(word='Peter', chars=5, uppercase=False, lowercase=False),
                       WordInfo(word='Piper', chars=5, uppercase=False, lowercase=False),
                       WordInfo(word='picked', chars=6, uppercase=False, lowercase=True),
                       WordInfo(word='a', chars=1, uppercase=False, lowercase=True),
                       WordInfo(word='peck', chars=4, uppercase=False, lowercase=True),
                       WordInfo(word='of', chars=2, uppercase=False, lowercase=True),
                       WordInfo(word='PICKLED', chars=7, uppercase=True, lowercase=False),
                       WordInfo(word='peppers.', chars=8, uppercase=False, lowercase=True)])

"""
5. Create a function called word_counts that accepts two string parameters called text and exclude.
- Split the string into words using str.split
- Create an empty dictionary
- For each word your word list
-    if the word is NOT equal to string passed to the exclude parameter
-       increment the integer associated with the word's key in the dictionary.
-       remember, you have to deal with the possibility that the word isn't currently in the dictionary (i.e., KeyError)!
-       Use the try/except method we say in class
- return the dictionary
"""
dash(5)

def word_counts(text: str, exclude: str):
    new_text=text.split(' ')
    dic={}
    for word in new_text:
        if word!=exclude:
            try:
                dic[word]+=1
            except KeyError:
                dic[word]=1
    return dic
s = "How much wood would a wood chuck chuck if a wood chuck could chuck wood"
pprint(word_counts(text=s, exclude="if"))
pprint(word_counts(text=s, exclude="if") == {'How': 1, 'a': 2, 'chuck': 4, 'could': 1, 'much': 1, 'wood': 4, 'would': 1})



"""
6. Your book shows you another method for making sure that avoid a KeyError when using a dictionary for counting.
Rewrite the word_counts function above as word_counts2 and instead of the try/except method, use the dict.get 
approach instead. Note: You can't use the += shortcut here.
"""
dash(6)

def word_counts2(text:str, exclude:str):
    new_text=text.split(' ')
    dic={}
    for word in new_text:
        if word!=exclude:
            dic[word]= dic.get(word, 0) +1
    return dic

s = "How much wood would a wood chuck chuck if a wood chuck could chuck wood"
pprint(word_counts2(text=s, exclude="if"))
pprint(word_counts2(text=s, exclude="if") == {'How': 1, 'a': 2, 'chuck': 4, 'could': 1, 'much': 1, 'wood': 4, 'would': 1})


"""
7. You've been given a text file called faculty_records.
-Import this module.
-Create a FacultyRecord namedtuple type with these fieldnames: first, last, phone, and sport
-Create a function called just_the_sports with a list parameter called records.
-Create an empty dictionary
-Loop over records 
-   For each record (each is a tuple of 4 items), create a FacultyRecord using the information in the tuple
    Note: You can use the star method we learned in class, or you can unpack them first. Either way is ok.
-   add to your dictionary a new item where the key is the last name from your record, 
    and the value is the sport from your record.
-Return the dictionary
Note: the collections module is already imported for you
"""
dash(7)
import faculty_records

# DEFINE YOUR NAMEDTUPLE HERE
FacultyRecord= collections.namedtuple('FacultyRecord', 'first last phone sport')
# DEFINE YOUR FUNCTION HERE
def just_the_sports(records: list):
    dic={}
    for record in records:
        entry = FacultyRecord(*record)
        dic[entry.last]=dic.get(entry.last, entry.sport)
    return dic
        

import faculty_records
pprint(just_the_sports(faculty_records.records[:5]))
print(just_the_sports(faculty_records.records[:5]) == {'Anderson': 'Skiing:', 'Bacolod': 'Hockey',
                                                       'Beswick': 'Shuttlecock', 'Dorin': 'Roller Sports',
                                                       'Carrillo': 'Gymnastics,'})
print(just_the_sports(faculty_records.records[-5:]) == {'Zandi': 'Kendo', 'Leong': 'Ice Hockey',
                                                        'Schreiber': 'Rugby League', 'Colombero': 'Practical Shooting',
                                                        'Webster': 'Kabaddi'})
