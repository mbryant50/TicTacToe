"""
Assignment 2

Please Note: Assignments are not meant to be group projects.
You must write your own code. Turning in code written by another student will result in you being reported to your
Provost for academic dishonesty. Learning and studying with others is fine, just do your own work. If you need help,
ask questions in class, come to office hours, or email us.

Warning: We know some of you may already know some python, or could find additional techniques by reading ahead in the
book or looking around online. That's fine, HOWEVER, you are to only use techniques we've covered in lecture or in the
book up to the week the assignment is given (includes the Thursday lecture the day after the assignment comes out).
We will be strict about this!

HOW TO TURN IN: You are to create the code files below, with the exact names specified below.
When finished, turn in all of your files on Canvas where you got the assignment prompt.
Do not email code to your instructor or TA! Code must be turned in via Canvas.
If you are turning in your code late, do it via Canvas (and incur the penalty – see the Syllabus).
If you can’t, then it’s too late even for late submission…there’s no benefit for your grade to emailing
us your code after this point.

"""
dashes = "-" * 20

"""
Instructions: See comments below, place you code beneath each one:
"""

"""
1. There are two different expressions you can write to make this code work. 
   The goal is to print the first message if age is not 0, otherwise, give the second message.
   Replace PUT_YOUR_CODE_HERE in each section with an expression that will make the code work as planned.
"""
print(f"{dashes}(1){dashes}")

age = 20
if age!=0:
    print("That's a non-zero age!")
else:
    print("What are you? A baby?!")

age = 0
if (bool(age==0))==False:
    print("That's a non-zero age!")
else:
    print("What are you? A baby?!")

"""
2. Use the random module to print a number between 10 and 60
"""
from random import *
print(f"{dashes}(2){dashes}")
print(randrange(10,60))

"""
3. Use the random module to print 25 numbers from 0 to 50.
   However, if the number 25 is generated, do not print it and instead break out of the while loop
"""
print(f"{dashes}(3){dashes}")

i=0
while i<25:
	x=randrange(0,50)
	if x==25:
		break
	else:
		print(x)
		i+=1
		

"""
4. Generate 25 random numbers between 1 and 100.
   Only print the even ones. 
   Note: You can check if a value is even by checking to see if that number mod 2 is zero.
   E.g.,  6 % 2 == 0, so 6 must be even
          9 % 2 != 0, so 9 must be odd
   Note: Use the continue statement in this answer.
"""
print(f"{dashes}(4){dashes}")

j=0
while j<25:
	z=randrange(1,100)
	if z%2==0:
		print(z)
		j+=1
	else:
		j+=1
		continue
"""
Assignment 2

Please Note: Assignments are not meant to be group projects.
You must write your own code. Turning in code written by another student will result in you being reported to your
Provost for academic dishonesty. Learning and studying with others is fine, just do your own work. If you need help,
ask questions in class, come to office hours, or email us.

Warning: We know some of you may already know some python, or could find additional techniques by reading ahead in the
book or looking around online. That's fine, HOWEVER, you are to only use techniques we've covered in lecture or in the
book up to the week the assignment is given (includes the Thursday lecture the day after the assignment comes out).
We will be strict about this!

HOW TO TURN IN: You are to create the code files below, with the exact names specified below.
When finished, turn in all of your files on Canvas where you got the assignment prompt.
Do not email code to your instructor or TA! Code must be turned in via Canvas.
If you are turning in your code late, do it via Canvas (and incur the penalty – see the Syllabus).
If you can’t, then it’s too late even for late submission…there’s no benefit for your grade to emailing
us your code after this point.

"""

dashes = "-" * 20

"""
Instructions: See comments below, place you code beneath each one:
"""

"""
5. **REPLACE** this function with an equivalent one using a for-loop instead of a while loop.
"""
print(f"{dashes}(5){dashes}")


def loop_replace():
    for x in range(5):
        x+=1
        print ('This is iteration number', x)
        """counter = 0
        while counter < 5:
        counter += 1
        print('This is iteration number', counter)"""


loop_replace()

"""
6. Create a function called guessing_game that takes a parameter called max_iterations and defaults to 4
use a **while loop** to loop max_iterations times. On each iteration:

Generate a random number from 1-10
Invite the user to enter a number from 1-10 or to enter the word 'pass'
If they enter "pass", skip over any remaining code in the block and start the guess over (i.e., use continue)
Convert their number to an integer
If their number is the same as your random guess, congratulate them! If it's not, tell them they got it wrong and 
reveal the actual number.
If they enter "" (i.e., they just hit the ENTER key without typing anything), tn thheey want to quit, so break out of 
the while loop and print "game over" (i.e., use break).
"""
print(f"{dashes}(6){dashes}")


def guessing_game(max_iterations=4):
	i=0
	while i<max_iterations:
		x=randrange(1,10)
		guess=input("Enter a number between 1 and 10, or enter pass "+
              "(alternatively, just hit 'enter' to end the game): ")
		if guess=='pass' or guess=='Pass' or guess=='PASS':
			i+=1
			continue
		elif guess=='':
			print("GAME OVER")
			break
		elif str(x)==guess:
			print('Congrats you got it!')
			i+=1
		else:
			print('Sorry bub, the number was', x,', try again smart guy')
			i+=1



guessing_game()

"""
7. Create a function called weeks that takes a parameter called max_weeks that defaults to 3
Use an embedded while (i.e., a while within a while) to produce this output:

Week 1
Day1 Day2 Day3 Day4 Day5 Day6 Day7
Week 2
Day1 Day2 Day3 Day4 Day5 Day5 Day7
Week 3
Day1 Day2 Day3 Day4 Day5 Day5 Day7

You can not have either of these strings in your code:
"Week 1", "Week 2", etc. (However, you CAN have the word "Week")
"Day1", "Day2", etc. (However, you CAN have the word "Day")
Thus, you need to generate "Week 1" by combining "Week" and the value of a loop counter from your outter loop.
Similarly, you can print Day and concatenate a string representation of the counter from your inner loop.
note: when printing days, add end=" " to each of your print statements so that they print next to each other instead 
of on top of each other.
"""
print(f"{dashes}(7){dashes}")



def weeks(max_weeks=3):
    i=0
    while i<max_weeks:
        i+=1
        print ('\nWeek', i)
        j=0
        while j<7:
            j+=1
            print('Day', str(j)+' ',end="")
    print('\n')
    
			


weeks()

"""
8. Write a **FRUITFUL** function called force_calc() that takes two parameters, mass and acceleration.
   Your function should return the product of these two values.
"""
print(f"{dashes}(8){dashes}")



def force_calc(mass, acceleration):
	force=mass*acceleration
	return force
	

# ******************************************************************
# **** UNCOMMENT THE NEXT 2 LINES TO TEST YOUR FORCE_CALC FUNCTION!!
# ******************************************************************
 
force = force_calc(mass=6, acceleration=23.4)
print("force =", force)

