"""
Assignment 7

Please Note: Assignments are not meant to be group projects.
You must write your own code. Turning in code written by another student will result in you being reported to your
Provost for academic dishonesty. Learning and studying with others is fine, just do your own work. If you need help,
ask questions in class, come to office hours, or email us.

Warning: We know some of you may already know some python, or could find additional techniques by reading ahead in the
book or looking around online. That's fine, HOWEVER, you are to only use techniques we've covered in lecture or in the
book up to the week the assignment is given (includes the Thursday lecture the day after the assignment comes out).
We will be strict about this!

HOW TO TURN IN: You are to create the code files below, with the exact names specified below.
When finished, turn in all of your files on Canvas where you got the assignment prompt.
Do not email code to your instructor or TA! Code must be turned in via Canvas.
If you are turning in your code late, do it via Canvas (and incur the penalty – see the Syllabus).
If you can’t, then it’s too late even for late submission…there’s no benefit for your grade to emailing
us your code after this point.

"""


def dash(d: int):
    dashes = "-" * 20
    print(f"\n{dashes}({d}){dashes}\n")


"""
Instructions: See comments below, place you code beneath each one:

**************************************************************************************
NOTES: 1. All functions require Type Hints!!
       2. You need to import your own modules!!
       3. You must use os-independent file paths (just let the Path module handle it!)
       4. This assignment can be done by following along with Tuesday's lecture slide
          notes posted on Canvas.
       5. In your functions that accepts a DataFrame and returns an altered one, 
          make sure you start by making a copy. For example:
          df = data_frame.copy()
          then alter and return df
       6. With the exception of the 1st function, all the others require the same
          exact parameter definition:  (data_frame: pandas.DataFrame)
**************************************************************************************
"""

"""
===================
WHAT IS THIS DATA?
===================
You've been given a folder full of data files.
They are from an experiment in which participants were asked to press a button as quickly and
as accurately as they could depending on whether the image had a positive valence or a
negative valence. 

Half the participants were older adjusts and half were younger adults.
On each trial, stimulus valence was randomly selected.
Response accuracy was recorded as "Correct" or "Incorrect"

You goal is to determine whether RT is influenced by AGE or COND (i.e., image valence).
Here are some quick tables to give you a sense of the structure of the data:

                              ID    RT
AGE     ACC       COND                
Older   Correct   Negative   862   862
                  Positive   966   966
        Incorrect Negative    82    82
                  Positive    81    81
Younger Correct   Negative  1044  1044
                  Positive   783   783
        Incorrect Negative   101   101
                  Positive    66    66
                  
                 RT            
COND       Negative    Positive
AGE                            
Older    607.382831  441.531056
Younger  488.028736  350.333333

"""

"""
1. Get the data

Load in all of the data from all participants into one pandas DataFrame.
Write a function called get_data that returns a single data frame containing all of the
data in the folder "data_files"
"""
import pandas
from pathlib import Path
import re

def get_data():
    files=Path('data_files').glob('*.csv')
    data_files=[]
    for file in files:
        new_data=pandas.read_csv(file)
        data_files.append(new_data)
    data_frame=pandas.DataFrame(pandas.concat(data_files))
    return data_frame



dash(1)
data = get_data()
print(data.shape)
print(data.shape == (3983, 6))
"""
2. Clean the data

Write a function called clean_data with a parameter called data_frame that is 
of type pandas.DataFrame.
Your function should copy the input data_frame and return a version with:
  a) the TRIAL column removed
  b) the COND column should be recoded so that "POS" is "Positive" and "NEG" is "Negative"
"""
def clean_data(data_frame: pandas.DataFrame):
    df=data_frame.drop(['TRIAL'], axis=1)
    new_cond=[]
    for item in df['COND']:
        if item=='POS':
            new_cond.append('Positive')
        if item=='NEG':
            new_cond.append('Negative')
    df['COND']=new_cond
    return df


dash(2)
data = clean_data(data_frame=data)
print(data.head())
print(set(data['COND']) == {'Positive', 'Negative'})  # test of (a)
print('TRIAL' not in data.columns)  # test of (b)

"""
3. Describe the data Part 1

Write a function called describe_me with a parameter called data_frame that is 
of type pandas.DataFrame  
Return a summary table that shows the count, mean, std, min, 25%-75%, and max of the RT column.
"""

def describe_me(data_frame: pandas.DataFrame):
    df=data_frame.copy()
    return df['RT'].describe()


dash(3)
table = describe_me(data_frame=data)
print(table)
expected = {'RT': {'count': 3985.0, 'mean': 452.6125470514429, 'std': 198.90426483471796,
                   'min': 13.0, '25%': 319.0, '50%': 429.0, '75%': 561.0, 'max': 1422.0}}
print(table.to_dict() == expected)

"""
4. RT Histogram

Write a function called rt_hist with a parameter called data_frame that is 
of type pandas.DataFrame  
Return a graph showing a histogram of the RT column with 20 bins
"""

def rt_hist(data_frame: pandas.DataFrame):
    graph= data['RT'].hist(bins=20)
    return graph



dash(4)
graph = rt_hist(data_frame=data)
figure = graph.get_figure()
figure.show()
figure.savefig('figure3.png')
print(Path('figure3png').is_file())

"""
5. RT Trim

Write a function called rt_trim with a parameter called data_frame that is 
of type pandas.DataFrame
Create a copy of the data frame, remove any RTs faster than 100 ms and slower than 900 ms.
Return this trimmed copy of the data frame.
"""
def rt_trim(data_frame: pandas.DataFrame):
    df=data_frame.query('RT >=100 and RT<=900')
    return df
    





dash(5)
data = rt_trim(data_frame=data)
print(describe_me(data_frame=data))
print()
print(describe_me(data_frame=data).loc['min'] >= 100)
print(describe_me(data_frame=data).loc['max'] <= 900)

"""
6. Categorized Counts

Write a function called cat_counts with a parameter called data_frame that is 
of type pandas.DataFrame
Return a table grouped by age and condition.
"""

def cat_counts(data_frame: pandas.DataFrame):
    df=data_frame.groupby(['AGE','COND']).count()
    return df


dash(6)
counts = cat_counts(data_frame=data)
print(counts)
expected = {'ID': {('Older', 'Negative'): 640, ('Older', 'Positive'): 1222,
                   ('Younger', 'Negative'): 620, ('Younger', 'Positive'): 1313},
            'RT': {('Older', 'Negative'): 640, ('Older', 'Positive'): 1222,
                   ('Younger', 'Negative'): 620, ('Younger', 'Positive'): 1313},
            'ACC': {('Older', 'Negative'): 640, ('Older', 'Positive'): 1222,
                    ('Younger', 'Negative'): 620, ('Younger', 'Positive'): 1313}}
print(counts.to_dict() == expected)

"""
7. Percent Errors

Write a function called pct_errors with a parameter called data_frame that is 
of type pandas.DataFrame
Return a single floating point value: the proportion of trials with an accuracy of "Incorrect"
"""

def pct_errors(data_frame: pandas.DataFrame):
    df=data_frame.groupby('ACC').count()
    correct, incorrect= df['RT']
    error = float(incorrect/(correct + incorrect))*100
    return error

dash(7)
print(pct_errors(data_frame=data))
print(pct_errors(data_frame=data) in (0.07957839262187089, 7.957839262187089))

"""
8. Categorized Descriptives

Write a function called cat_descriptives with a parameter called data_frame that is 
of type pandas.DataFrame
Return a table showing mean RT categorized by AGE and COND for Correct trials only
"""

def cat_descriptives(data_frame: pandas.DataFrame):
    df=data_frame.query('ACC=="Correct"').groupby(['AGE', 'COND']).mean()
    return df



dash(8)
table = cat_descriptives(data_frame=data)
print(table)
expected = {'RT': {('Older', 'Negative'): 572.0259515570934,
                   ('Older', 'Positive'): 444.3113879003559,
                   ('Younger', 'Negative'): 492.07272727272726,
                   ('Younger', 'Positive'): 361.8767123287671}}

print(table.to_dict() == expected)

"""
9. Correct RT by Condition Graph

Write a function called cond_rt_graph with a parameter called data_frame that is 
of type pandas.DataFrame
Return a bar graph showing mean RT categorized by COND for Correct trials only
"""

def cond_rt_graph(data_frame: pandas.DataFrame):
    df=data_frame.query('ACC=="Correct"').groupby(['COND']).mean()
    graph= df.plot(kind='bar', title='Mean Response Time For Correct Trials Only', rot=0)
    return graph


dash(9)
graph = cond_rt_graph(data_frame=data)
figure = graph.get_figure()
figure.show()
figure.savefig('figure8.png')
print(Path('figure8.png').is_file())

"""
10. T-test on RT by Age and RT by Cond

Write a function called stat_tests with a parameter called data_frame that is 
of type pandas.DataFrame
Return a tuple of the 2 namedtuples that result from these independent samples t-tests:
  a) Younger participant RTs vs Older participant RTs
  b) Positive valence RTs vs Negative valence RTs
Only analyze RTs from Correct trials
NOTE: You don't need to create the namedtuples, scipy.stats's ttest functions return them.
Disable equal variances!
"""
import scipy.stats
def stat_tests(data_frame: pandas.DataFrame):
    yung=data_frame.query('ACC=="Correct"').query('AGE=="Younger"')['RT']
    old=data_frame.query('ACC=="Correct"').query('AGE=="Older"')['RT']
    posit=data_frame.query('ACC=="Correct"').query('COND=="POS"')['RT']
    negat=data_frame.query('ACC=="Correct"').query('COND=="NEG"')['RT']
    res1=scipy.stats.ttest_ind(a=yung, b=old, equal_var=False)
    res2=scipy.stats.ttest_ind(a=posit, b=negat, equal_var=False)
    return (res1, res2)




dash(10)
age_ttest, cond_ttest = stat_tests(data_frame=data)
print('RT by AGE T-TEST:', age_ttest)
print('RT by COND T-TEST:', cond_ttest)
print(age_ttest == (-15.43668273241714, 5.2478653528152724e-52))
print(cond_ttest == (-20.841385670244108, 2.9201482866779881e-86))