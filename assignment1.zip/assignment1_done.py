from random import *
"""
Assignment 1

Please Note: Assignments are not meant to be group projects.
You must write your own code. Turning in code written by another student will result in you being reported to your
Provost for academic dishonesty. Learning and studying with others is fine, just do your own work. If you need help,
ask questions in class, come to office hours, or email us.

Warning: We know some of you may already know some python, or could find additional techniques by reading ahead in the
book or looking around online. That's fine, HOWEVER, you are to only use techniques we've covered in lecture or in the
book up to the week the assignment is given (includes the Thursday lecture the day after the assignment comes out).
We will be strict about this!

HOW TO TURN IN: You are to create the code files below, with the exact names specified below.
When finished, turn in all of your files on Canvas where you got the assignment prompt.
Do not email code to your instructor or TA! Code must be turned in via Canvas.
If you are turning in your code late, do it via Canvas (and incur the penalty – see the Syllabus).
If you can’t, then it’s too late even for late submission…there’s no benefit for your grade to emailing
us your code after this point.

"""

"""
Instructions: See comments below, place you code beneath each one:
"""



"""
1. Create 3 variables and assign to one an int, to another a float, and to the last one a str
"""
x=1
y=5.0
z="string"


"""
2. Print your 3 variables an their types so that each statement is exactly like this,
except use your own variables and values:
                      v--Put your variable name here
                      |                 v--Print the value of your variable here
                      v                 v             v--The type of your variable goes here
  The variable called age has the value 23 and is a <class 'int'>
"""
print("The variable called x has the value " + str(x) + " and is a " + 
      str(type(x)))
print("The variable called y has the value " + str(y) + " and is a " + 
      str(type(y)))
print("The variable called z has the value " + str(z) + " and is a " + 
      str(type(z)))


"""
3. Ask the user to input their show size. Then print a statement like this:

  Your shoe size is 11.5; The next size down is 11.0; The next size up is 12.0
"""
def shoe_size():
  x=input("What is your shoe size? (enter x.5 if half): ")
  print("Your shoe size is " + str(x) + "; The next size down is " +
        str(float(x)-.5) + "; The next size up is " + str(float(x)+.5))
shoe_size()


"""
4. Create a print statement that produces the EXACT text on the line below this one (quotes and all):
Hello "World"!!
"""
print('Hello "World"!!')
"""
Assignment 1

Please Note: Assignments are not meant to be group projects.
You must write your own code. Turning in code written by another student will result in you being reported to your
Provost for academic dishonesty. Learning and studying with others is fine, just do your own work. If you need help,
ask questions in class, come to office hours, or email us.

Warning: We know some of you may already know some python, or could find additional techniques by reading ahead in the
book or looking around online. That's fine, HOWEVER, you are to only use techniques we've covered in lecture or in the
book up to the week the assignment is given (includes the Thursday lecture the day after the assignment comes out).
We will be strict about this!

HOW TO TURN IN: You are to create the code files below, with the exact names specified below.
When finished, turn in all of your files on Canvas where you got the assignment prompt.
Do not email code to your instructor or TA! Code must be turned in via Canvas.
If you are turning in your code late, do it via Canvas (and incur the penalty – see the Syllabus).
If you can’t, then it’s too late even for late submission…there’s no benefit for your grade to emailing
us your code after this point.

"""

"""
Instructions: See comments below, place you code beneath each one:
"""


"""
5. Ask the user to enter their age. Respond with "Too young for college." if they enter a value lower than 13.
   Otherwise, respond with "Seems legit."
"""
def enter_age():
  x=input("Enter your age: ")
  if int(x)<13:
    print("Too young for college")
  else:
    print("Seems legit")
enter_age()
	
	
"""
6. Tip Calculator

Ask the user what tip rate they want (e.g., they can enter .15, .18, .20, etc...)
If they enter a number < .05 or > .25, 
    inform them to enter a more reasonable tip amount next time and stop.
otherwise,
    ask them for the meal price
    use the tip rate and the meal price to compute tip
    Show user the tip for their meal 

  
Sample Runs:
    Run 1
        What tip rate do you want to use [.05 to .25]: 34
        Next time, enter a more reasonable tip rate.

    Run 2
        What tip rate do you want to use [.05 to .25]: .15
        Enter the price of the meal: 16.87
        The tip for your meal is $ 2.5305 and the total price is $ 19.4005
"""

def tip_calc():
  x=input("What tip rate do you want to use? [.05 to .25]: ")
  if float(x)<.05 or float(x)>.25:
    print("Hold your horses partner, tip like a normal person")
  else:
    y=input("Enter the price of the meal: ")
    z=float(x)*float(y)
    k=float(z)+float(y)
    print("The tip for your meal is $" + str(z) + " and the total price is $" + str(k))
tip_calc()
print("")
print("")
"""
7. Random Thirds
Use a while loop that loops 50 times.
    randomly generate a number between 1 and 100
    if that number is less than 33, print "Lower Third"
    If that number is less > 33 but less than 66, print "Middle Third"
    If that number is > 66, print "Upper Third"
Don't forget that you first have to import the random module
"""

def random_thirds():
  i=0
  while(i<50):
    x=randrange(1,100)
    if x<=33:
      print("Lower Third")
    elif (x>33 and x<66):
      print("Middle Third")
    else:
      print("Upper third")
    i+=1
random_thirds()

print("______________________________________________________________________")
print("")
"""
8. Random Thirds Redux
Produce the same output as #7, except use a for loop over a range instead of a while loop.
"""
def random_thirds_redux():
  for i in range(50):
    x=randrange(1,100)
    if x<=33:
      print("Lower Third")
    elif x>33 and x<66:
      print("Middle Third")
    else:
      print("Upper third")
random_thirds_redux()