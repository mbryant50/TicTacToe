"""
Assignment 8

Please Note: Assignments are not meant to be group projects.
You must write your own code. Turning in code written by another student will result in you being reported to your
Provost for academic dishonesty. Learning and studying with others is fine, just do your own work. If you need help,
ask questions in class, come to office hours, or email us.

Warning: We know some of you may already know some python, or could find additional techniques by reading ahead in the
book or looking around online. That's fine, HOWEVER, you are to only use techniques we've covered in lecture or in the
book up to the week the assignment is given (includes the Thursday lecture the day after the assignment comes out).
We will be strict about this!

HOW TO TURN IN: You are to create the code files below, with the exact names specified below.
When finished, turn in all of your files on Canvas where you got the assignment prompt.
Do not email code to your instructor or TA! Code must be turned in via Canvas.
If you are turning in your code late, do it via Canvas (and incur the penalty – see the Syllabus).
If you can’t, then it’s too late even for late submission…there’s no benefit for your grade to emailing
us your code after this point.
"""
from pprint import pprint
import re


def dash(d: int):
    dashes = "-" * 20
    print(f"\n{dashes}({d}){dashes}\n")


def tag2str(tags: list):
    return [str(tag) for tag in tags]


"""
Instructions: See comments below, place you code beneath each one:

**************************************************************************************
NOTES: 1. All functions require Type Hints!!
       2. You need to import your own modules!!
       3. You must use os-independent file paths (just let the Path module handle it!)
**************************************************************************************
"""

fake_atags = \
    ['<a class="topnav_tertiary_title"><h2>Clothing</h2></a>',
     '<a href="https://www.thinkgeek.com/"><i>Note: These links are from the site http://www.thinkgeek.com</i></a>',
     '<a href="https://www.thinkgeek.com/clothing/t-shirts/">T-Shirts</a>',
     '<a href="https://www.thinkgeek.com/clothing/tank-tops-fitted-tees/">Tank Tops &amp; Fitted Tees</a>',
     '<a href="https://www.thinkgeek.com/clothing/polos-button-ups/">Polos &amp; Button-Ups</a>',
     '<a href="https://www.thinkgeek.com/clothing/womens-tops/">Women&amp;apos;s Tops</a>',
     '<a href="https://www.thinkgeek.com/clothing/dresses-skirts/">Dresses &amp; Skirts</a>',
     '<a href="https://www.thinkgeek.com/clothing/sweaters-cardigans/">Sweaters &amp; Cardigans</a>',
     '<a href="https://www.thinkgeek.com/clothing/hoodies/">Hoodies</a>',
     '<a href="https://www.thinkgeek.com/clothing/jackets-outerwear/">Jackets &amp; Outerwear</a>',
     '<a href="https://www.thinkgeek.com/clothing/activewear-swimwear/">Activewear &amp; Swimwear</a>',
     '<a href="https://www.thinkgeek.com/clothing/robes/">Robes</a>',
     '<a href="https://www.thinkgeek.com/clothing/sleepwear/">Sleepwear</a>',
     '<a href="https://www.thinkgeek.com/clothing/leggings/">Leggings</a>',
     '<a href="https://www.thinkgeek.com/clothing/socks-underwear/">Socks &amp; Underwear</a>',
     '<a href="https://www.thinkgeek.com/clothing/baby-kids/">Baby &amp; Kids</a>',
     '<a href="https://www.thinkgeek.com/clothing/costume-cosplay-apparel/">Costume &amp; Cosplay Apparel</a>']

lil_fake_atags = \
    ['<a href="https://www.thinkgeek.com/clothing/jackets-outerwear/">Jackets &amp; Outerwear</a>',
     '<a href="https://www.thinkgeek.com/clothing/activewear-swimwear/">Activewear &amp; Swimwear</a>',
     '<a href="https://www.thinkgeek.com/clothing/sleepwear/">Sleepwear</a>',
     '<a href="https://www.thinkgeek.com/clothing/socks-underwear/">Socks &amp; Underwear</a>']

"""
1. Find the tag
Write a function called get_tags with a string parameter called the_tag and another
parameter called the_html_path that is a pathlib Path object. Return a list of all the 
tags in the html identified with the string referred to in the_tag. For more information, 
see the test code below.

Note: The file you'll be loading will contains HTML as normal utf-8 text. Because you're 
loading it from the disk and not the web, you don't need requests.get() and because it's
already utf-8 text, you don't need bytes.encode('utf-8'). 
Just convert the text to a soup object and move forward from there.
"""
dash(1)

from pathlib import Path
from bs4 import BeautifulSoup

def get_tags(the_tag: str, the_html_path: Path):
    contents= the_html_path.read_text()
    soup= BeautifulSoup(contents, 'html.parser')
    return soup.find_all(the_tag)



tags = get_tags(the_tag="a", the_html_path=Path('files', 'fake.html'))
pprint(tags)
print(tag2str(tags) == fake_atags)

"""
2. Find my tag LINK EDITION
write a new function that called get_link_tags that is exactly the same as
the get_tags function above, except that it has an extra boolean parameter called
links_only that defaults to False. Your function should return only tags that 
match the the_tag parameter just like before. However, if links_only is True, 
then you should only return tags that have an href attribute.
"""
dash(2)

def get_link_tags(the_tag:str, the_html_path:Path, links_only: bool = False):
    contents= the_html_path.read_text()
    soup= BeautifulSoup(contents, 'html.parser')
    all_tags= soup.find_all(the_tag)
    if links_only==False:
        return all_tags
    else:
        return [tag for tag in all_tags if 'href' in str(tag)]

link_tags1 = get_link_tags(the_tag="a", the_html_path=Path('files', 'fake.html'))
link_tags2 = get_link_tags(the_tag="a", the_html_path=Path('files', 'fake.html'), links_only=True)
pprint(link_tags1)
print(tag2str(link_tags1) == fake_atags)
print()
pprint(link_tags2)
print(tag2str(link_tags2) == fake_atags[1:])

"""
3. Find my tag QUALIFIED EDITION
write a new function that called get_qualified_tags that is exactly the same as
the get_tags function above (start with a copy of the original get_tags function), 
except this function has an extra string parameter called requirement. Only return
tags whose contents (i.e., the text between the tags) contains the string associated
with the parameter called requirement.

Hint: Don't forget that tag.contents is a list, but some tag.contents are empty lists.
Thus, even though you only have to worry about tag.contents[0], you need to first check
that tag.contents is not empty before trying to index tag.contents[0].
"""
dash(3)

def get_qualified_tags(the_tag: str, the_html_path: Path, requirement: str):
    contents= the_html_path.read_text()
    soup= BeautifulSoup(contents, 'html.parser')
    all_tags=soup.find_all(the_tag)
    ret_val=[]
    for tag in all_tags:
        if tag.contents[0]==None:
            continue
        else:
            if requirement in str(tag.contents[0]):
                ret_val.append(tag)
    return ret_val


qualified_tags = get_qualified_tags(the_tag="a", the_html_path=Path('files', 'fake.html'), requirement="wear")
pprint(qualified_tags)
print(tag2str(qualified_tags) == lil_fake_atags)

"""
4. Find my tag EMBEDDED EDITION
Write a function called get_tags_embedded that is the same as the get_tags function 
above except that it only returns tags (specified by the the_tag parameter) that are 
themselves within <li></li> tags. 

So if the_tag was "a", the a-tag in this line would be included in the result: 
<li><a href="https://www.thinkgeek.com/clothing/t-shirts/">T-Shirts</a></li>
but this a-tag would not:
<a class="topnav_tertiary_title"><h2>Clothing</h2></a>

Hint: They key to remember here is that in BeautifulSoup, .find_all() and .find() return 
something that may look like strings, but are actually BeautifulSoup objects that themselves 
have .find() and .find_all() methods. Thus, a way to do a conjunctive search (i.e, find 
something with a 'li' tag AND an 'a' tag), is  ot first get a list of tags of one type, 
and then loop through those and see which ones have the other kind of tag.

Hint2: If you're looking for ALL of something, use find_all() (it returns a list of all things 
found...or an empty list if there are none), but if you're just looking for at least one of 
something, then use find() (it just returns the first thing, or None if there isn't one)
"""
dash(4)

def get_tags_embedded(the_tag: str, the_html_path: Path):
    contents= the_html_path.read_text()
    soup= BeautifulSoup(contents, 'html.parser')
    search_tags=soup.find_all("li")
    ret_val=[]
    for tag in search_tags:
        if tag.find(the_tag)!=None:
            ret_val.append(tag.find(the_tag))
    return ret_val



tags = get_tags_embedded(the_tag="a", the_html_path=Path('files', 'fake.html'))
pprint(tags)
if tag2str(tags) == fake_atags[2:]:
    print('full credit - printed a-tags within li-tags')
elif ''.join(tag2str(tags)).count('<li>') == 15 and \
        ([re.sub(r'</?li>', '', item) for item in tag2str(tags)] == fake_atags[2:]):
    print('3/4 credit - printed only a-tags within li-tags, but failed to extract a-tags')

"""
5. Random List GUI
   
write a function called my_gui that creates an appjar gui.

At the top is a NUMERIC ENTRY box entitled "BadNumber" with a default value of 13, 
You can read about numeric entry boxes here: http://appjar.info/inputWidgets/#entry

Under that widget should be an empty list box with 10 empty lines.
You can add empty lines by setting the values parameters to [''] * 10
You can read about list boxes here: http://appjar.info/inputWidgets/#listbox

Under the list box should be a button called quit that quits the gui when pressed

Within your my_gui function, create an embedded function called random_nums that:
1) clears the list box items
2) adds 10 list items to the box, each with one randomly generated number between 1 and 20 on it

Create an appjar infinite loop that calls random_nums every 2 seconds (i.e, a poll time of 2000)
You can read about appjar infinite loops (adn how to set the interval to 2 seconds) here: 
http://appjar.info/pythonLoopsAndSleeps/#infinite-loops   

The result should look like this: https://goo.gl/epWSmD
"""
import random
dash(5)
from appJar import gui
def my_gui():
    
    def random_nums():
        app.clearListBox("")
        nums=[random.randrange(1,20) for i in range(10)]
        i=0
        while i < len(nums):
            app.setListItemAtPos("", i, nums[i])

    app= gui()
    app.addNumericEntry("BadNumber")
    app.setEntryDefault("BadNumber", "13")
    app.addListBox("",[""]*10)
    app.addButton("quit", app.stop)
    app.registerEvent(random_nums)
    app.setPollTime(2000)
    app.go()
    
    
my_gui()

"""
6. 
========= IMPORTANT NOTE ==========
For question number 6, you have the option of either doing what is stated below 
 (the Airport Status Lookup problem describe below)
 
--OR--

You can write a copy of my_gui called my_gui2 where each of the lines of the listbox 
 has a green background when it is NOT the number entered into the BadNumber box, 
 and white background when it is not.
===================================

Airport Status Lookup
Take a look at the result of this web-api (application programming interface) lookup:
http://www.fly.faa.gov/flyfaa/AirportLookup.jsp?q=SJC

Write a function called airport_status that takes one string parameter called airport.
Use either requests and BeautifulSoup --OR-- requests_html, but not both.
Return a namedtuple called AirPortDelay with 3 attributes: airport, arrival, and departure.
airport: this should just be a copy of the input parameter airport
arrival: this should be just the text contents of the arrival delay information found 
within this page's html
departure: the same, but for departure delay information.
 
1) You will have to look at the source of an example page 
   (e.g., http://www.fly.faa.gov/flyfaa/AirportLookup.jsp?q=SJC)
   and figure out which tag or tags surround the departure and arrival information.
2) The actual information you want may be within a tag's contents. If so, you may need to think about
   whether it is the 1st, 2nd, etc. element in the contents list so you can extract just the info
   you are looking for. 
3) In order to find the tag you want, you may need to search within another tag's 
   contents. The key is to take it one step at a time and print out the result of each step as you go
   before programming the next.
3) There is no universal right answer for this question because the arrival/departure delay information
   may change from one moment to the next. However, your result will look something like this:
   AirPortDelay(airport='SJC', 
                arrival=' Arrival traffic is experiencing airborne delays of 15 minutes or less. ',
                departure=' Traffic is experiencing gate hold and taxi delays lasting 15 minutes or less ')
   or
      AirPortDelay(airport='SJC', 
                arrival=[' Arrival traffic is experiencing airborne delays of 15 minutes or less. '],
                departure=[' Traffic is experiencing gate hold and taxi delays lasting 15 minutes or less '])
   (we don't care whether you leave it as a list)
4) Define your namedtuple INSIDE YOUR FUNCTION on the 1st line
5) Unlike the above questions, you will need to use the requests module to get and encode the text from the web.
"""
dash(6)
import collections
def airport_status(airport:str):
    AirPortDelay= collections.namedtuple('AirPortDelay', 'airport arrival departure')
    


# delays = airport_status(airport='SJC')
# print(f'Airport Status for {delays.airport}')
# print('-' * 22)
# print(f'Arrival Delay Information:\t{delays.arrival}')
# print(f'Departure Delay Information:\t{delays.departure}')

# --OR--

# my_gui2()